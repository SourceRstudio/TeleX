package com.telex.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val TelegramBlue = Color(0xFF3390EC)

data class Chat(
    val id: Int,
    val name: String,
    val preview: String,
    val time: String,
    val avatar: String,
    val unread: Int = 0,
    val online: Boolean = false
)
data class Message(val text: String, val mine: Boolean, val time: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TeleXApp() }
    }
}

@Composable
fun TeleXApp() {
    var dark by remember { mutableStateOf(false) }
    var selectedTab by remember { mutableIntStateOf(0) }
    var activeChat by remember { mutableStateOf<Chat?>(null) }
    var query by remember { mutableStateOf("") }
    val chats = remember {
        mutableStateListOf(
            Chat(1, "Александр", "Привет! Как дела?", "19:42", "А", 2, true),
            Chat(2, "Мария", "Отправила фото 📷", "19:30", "М", 0, true),
            Chat(3, "Друзья", "Давайте встретимся завтра", "18:56", "Д", 5),
            Chat(4, "Работа", "Документы готовы", "18:20", "Р", 0),
            Chat(5, "Иван", "Спасибо большое!", "Вчера", "И", 0)
        )
    }
    val messages = remember {
        mutableStateMapOf(
            1 to mutableStateListOf(
                Message("Привет! Как дела?", false, "19:40"),
                Message("Всё отлично! А у тебя?", true, "19:41"),
                Message("Тоже хорошо 😊", false, "19:42")
            )
        )
    }

    MaterialTheme(colorScheme = if (dark) darkColorScheme(
        primary = TelegramBlue, background = Color(0xFF17212B),
        surface = Color(0xFF17212B), onSurface = Color(0xFFE8EEF4)
    ) else lightColorScheme(
        primary = TelegramBlue, background = Color(0xFFFFFFFF),
        surface = Color(0xFFFFFFFF), onSurface = Color(0xFF17212B)
    )) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            if (activeChat != null) {
                ChatScreen(
                    chat = activeChat!!,
                    messages = messages.getOrPut(activeChat!!.id) { mutableStateListOf() },
                    onBack = { activeChat = null }
                )
            } else {
                MainScreen(
                    chats = chats,
                    selectedTab = selectedTab,
                    onTab = { selectedTab = it },
                    query = query,
                    onQuery = { query = it },
                    dark = dark,
                    onTheme = { dark = !dark },
                    onOpenChat = { activeChat = it }
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    chats: List<Chat>, selectedTab: Int, onTab: (Int) -> Unit,
    query: String, onQuery: (String) -> Unit, dark: Boolean,
    onTheme: () -> Unit, onOpenChat: (Chat) -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        when (selectedTab) { 1 -> "Контакты"; 2 -> "Настройки"; else -> "TeleX" },
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onTheme) {
                        Icon(if (dark) Icons.Default.LightMode else Icons.Default.DarkMode, "Сменить тему")
                    }
                },
                actions = {
                    IconButton(onClick = {}) { Icon(Icons.Default.Edit, "Новое сообщение") }
                    IconButton(onClick = {}) { Icon(Icons.Default.MoreVert, "Меню") }
                }
            )
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(selectedTab == 0, { onTab(0) }, icon = { Icon(Icons.Default.Chat, null) }, label = { Text("Чаты") })
                NavigationBarItem(selectedTab == 1, { onTab(1) }, icon = { Icon(Icons.Default.Contacts, null) }, label = { Text("Контакты") })
                NavigationBarItem(selectedTab == 2, { onTab(2) }, icon = { Icon(Icons.Default.Settings, null) }, label = { Text("Настройки") })
            }
        },
        floatingActionButton = {
            if (selectedTab == 0) FloatingActionButton(onClick = { onTab(1) }, containerColor = TelegramBlue, contentColor = Color.White) {
                Icon(Icons.Default.Edit, "Новый чат")
            }
        }
    ) { padding ->
        when (selectedTab) {
            0 -> Column(Modifier.padding(padding)) {
                OutlinedTextField(
                    value = query, onValueChange = onQuery,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                    placeholder = { Text("Поиск") },
                    leadingIcon = { Icon(Icons.Default.Search, null) },
                    singleLine = true,
                    shape = RoundedCornerShape(24.dp)
                )
                LazyColumn {
                    items(chats.filter { it.name.contains(query, true) || it.preview.contains(query, true) }) { chat ->
                        ChatRow(chat) { onOpenChat(chat) }
                    }
                }
            }
            1 -> Column(Modifier.padding(padding)) {
                listOf("Александр", "Мария", "Иван", "Екатерина", "Дмитрий").forEachIndexed { i, name ->
                    ChatRow(Chat(100 + i, name, "Пользователь TeleX", "", name.take(1), online = i < 2)) {}
                }
            }
            else -> Column(Modifier.padding(padding).padding(20.dp)) {
                Text("Ваш профиль", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(18.dp))
                Avatar("Т", 72)
                Spacer(Modifier.height(12.dp))
                Text("Пользователь TeleX", style = MaterialTheme.typography.titleLarge)
                Text("@telex_user", color = MaterialTheme.colorScheme.onSurface.copy(alpha = .6f))
                HorizontalDivider(Modifier.padding(vertical = 20.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.DarkMode, null)
                    Spacer(Modifier.width(12.dp))
                    Text("Тёмная тема", Modifier.weight(1f))
                    Switch(checked = dark, onCheckedChange = { onTheme() })
                }
                ListItem(headlineContent = { Text("Уведомления") }, leadingContent = { Icon(Icons.Default.Notifications, null) })
                ListItem(headlineContent = { Text("Конфиденциальность") }, leadingContent = { Icon(Icons.Default.Lock, null) })
                ListItem(headlineContent = { Text("О приложении") }, supportingContent = { Text("TeleX 1.0.0") }, leadingContent = { Icon(Icons.Default.Info, null) })
            }
        }
    }
}

@Composable
fun Avatar(letter: String, size: Int = 52) {
    Box(
        Modifier.size(size.dp).clip(CircleShape).background(Color(0xFF5B9BD5)),
        contentAlignment = Alignment.Center
    ) { Text(letter.take(1), color = Color.White, fontSize = (size / 2.4).sp, fontWeight = FontWeight.Bold) }
}

@Composable
fun ChatRow(chat: Chat, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box {
            Avatar(chat.avatar, 54)
            if (chat.online) Box(Modifier.align(Alignment.BottomEnd).size(13.dp).clip(CircleShape).background(Color(0xFF4CAF50)))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(chat.name, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
            Text(chat.preview, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .62f), maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 14.sp)
        }
        Column(horizontalAlignment = Alignment.End) {
            Text(chat.time, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .55f))
            if (chat.unread > 0) {
                Spacer(Modifier.height(5.dp))
                Box(Modifier.clip(CircleShape).background(TelegramBlue).padding(horizontal = 7.dp, vertical = 2.dp)) {
                    Text(chat.unread.toString(), color = Color.White, fontSize = 11.sp)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(chat: Chat, messages: MutableList<Message>, onBack: () -> Unit) {
    var draft by remember { mutableStateOf("") }
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(chat.name, fontWeight = FontWeight.SemiBold)
                        Text(if (chat.online) "в сети" else "был(а) недавно", fontSize = 12.sp, color = TelegramBlue)
                    }
                },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Назад") } },
                actions = {
                    IconButton(onClick = {}) { Icon(Icons.Default.Call, "Позвонить") }
                    IconButton(onClick = {}) { Icon(Icons.Default.MoreVert, "Меню") }
                }
            )
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            LazyColumn(
                Modifier.weight(1f).fillMaxWidth().padding(horizontal = 12.dp),
                reverseLayout = false,
                verticalArrangement = Arrangement.Bottom
            ) {
                items(messages) { msg ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (msg.mine) Arrangement.End else Arrangement.Start) {
                        Column(
                            Modifier.padding(vertical = 4.dp).widthIn(max = 300.dp)
                                .clip(RoundedCornerShape(18.dp))
                                .background(if (msg.mine) Color(0xFFD9FDD3) else MaterialTheme.colorScheme.surfaceVariant)
                                .padding(horizontal = 13.dp, vertical = 9.dp)
                        ) {
                            Text(msg.text, color = Color(0xFF17212B), fontSize = 15.sp)
                            Text(msg.time, Modifier.align(Alignment.End), color = Color.DarkGray.copy(alpha = .65f), fontSize = 10.sp)
                        }
                    }
                }
            }
            Row(
                Modifier.fillMaxWidth().padding(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = {}) { Icon(Icons.Default.AttachFile, "Прикрепить файл") }
                OutlinedTextField(
                    value = draft, onValueChange = { draft = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("Сообщение") },
                    shape = RoundedCornerShape(26.dp),
                    maxLines = 4
                )
                IconButton(onClick = {
                    if (draft.isNotBlank()) {
                        messages.add(Message(draft.trim(), true, "сейчас"))
                        draft = ""
                    }
                }) { Icon(Icons.Default.Send, "Отправить", tint = TelegramBlue) }
            }
        }
    }
}
