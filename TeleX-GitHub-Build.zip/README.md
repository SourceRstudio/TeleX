# TeleX — Android messenger starter

TeleX is a native Android project built with Kotlin and Jetpack Compose. The UI is inspired by familiar messenger patterns; it is an independent project and is not affiliated with Telegram.

## Included
- Chat list with search and unread counters
- Chat screen with local in-memory message sending
- Contacts and profile/settings screens
- Light/dark theme toggle
- Native Android project structure

## Open and run
1. Install Android Studio (Ladybug or newer) and Android SDK 35.
2. Open this folder in Android Studio.
3. Allow Gradle sync.
4. Run the `app` configuration on an Android device or emulator (Android 8.0 / API 26 or newer).

## Important: backend is not connected yet
This version is a runnable UI prototype. Messages are stored in memory and disappear when the app process is restarted. Registration, real multi-device delivery, push notifications, media upload, and server-side storage require a backend.

A production architecture can use:
- Firebase Authentication for phone/email sign-in
- Cloud Firestore for users, chats, and messages
- Firebase Storage for media
- Firebase Cloud Messaging for push notifications
- Firestore Security Rules to restrict access to chat members

To enable Firebase, create an Android app with package `com.telex.app` in Firebase Console, download `google-services.json` into `app/`, then add the Google Services Gradle plugin and Firebase BoM/dependencies. Implement phone verification and security rules before deploying.

## Suggested next milestones
1. Add Firebase Authentication and onboarding.
2. Replace in-memory chat state with Firestore repositories.
3. Add image/file picker and Firebase Storage uploads.
4. Add FCM push notifications.
5. Add group creation, message replies, reactions, and delivery/read states.

## Build details
- Kotlin 2.0.21
- Android Gradle Plugin 8.7.3
- Jetpack Compose BOM 2024.12.01
- minSdk 26 / targetSdk 35
